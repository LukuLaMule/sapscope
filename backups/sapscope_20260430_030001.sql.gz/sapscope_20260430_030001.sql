--
-- PostgreSQL database dump
--

\restrict 1a44CUcYCeOAkmbgbmqGj60webjRdVg8ozfChaGkVt9ZKG6VdjXTGY8NjOPXz0V

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_tokens; Type: TABLE; Schema: public; Owner: sapscope
--

CREATE TABLE public.agent_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_id uuid NOT NULL,
    label character varying(255) NOT NULL,
    token_hash character(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    is_revoked boolean DEFAULT false NOT NULL
);


ALTER TABLE public.agent_tokens OWNER TO sapscope;

--
-- Name: analyses; Type: TABLE; Schema: public; Owner: sapscope
--

CREATE TABLE public.analyses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    snapshot_id uuid NOT NULL,
    model character varying(80) NOT NULL,
    input_tokens integer NOT NULL,
    output_tokens integer NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    language character varying(30) DEFAULT 'English'::character varying NOT NULL
);


ALTER TABLE public.analyses OWNER TO sapscope;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: sapscope
--

CREATE TABLE public.clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.clients OWNER TO sapscope;

--
-- Name: health_checks; Type: TABLE; Schema: public; Owner: sapscope
--

CREATE TABLE public.health_checks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    snapshot_id uuid NOT NULL,
    score smallint NOT NULL,
    status character varying(10) NOT NULL,
    indicators jsonb DEFAULT '{}'::jsonb NOT NULL,
    computed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT health_checks_score_check CHECK (((score >= 0) AND (score <= 100))),
    CONSTRAINT health_checks_status_check CHECK (((status)::text = ANY ((ARRAY['OK'::character varying, 'WARNING'::character varying, 'CRITICAL'::character varying, 'UNKNOWN'::character varying])::text[])))
);


ALTER TABLE public.health_checks OWNER TO sapscope;

--
-- Name: licenses; Type: TABLE; Schema: public; Owner: sapscope
--

CREATE TABLE public.licenses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    key character varying(36) NOT NULL,
    email character varying(255),
    plan character varying(50) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    activated_at timestamp with time zone,
    instance_id character varying(255),
    active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.licenses OWNER TO sapscope;

--
-- Name: onboarding_tokens; Type: TABLE; Schema: public; Owner: sapscope
--

CREATE TABLE public.onboarding_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    token_plaintext character varying(512) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.onboarding_tokens OWNER TO sapscope;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: sapscope
--

CREATE TABLE public.password_reset_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(64) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.password_reset_tokens OWNER TO sapscope;

--
-- Name: snapshots; Type: TABLE; Schema: public; Owner: sapscope
--

CREATE TABLE public.snapshots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_id uuid NOT NULL,
    system_sid character varying(10) NOT NULL,
    system_host character varying(255) NOT NULL,
    schema_version character varying(10) NOT NULL,
    collected_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    payload jsonb NOT NULL
);


ALTER TABLE public.snapshots OWNER TO sapscope;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: sapscope
--

CREATE TABLE public.subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    stripe_customer_id character varying(255) NOT NULL,
    stripe_subscription_id character varying(255),
    tier character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscriptions OWNER TO sapscope;

--
-- Name: system_notes; Type: TABLE; Schema: public; Owner: sapscope
--

CREATE TABLE public.system_notes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_id uuid NOT NULL,
    system_sid character varying(10) NOT NULL,
    content text NOT NULL,
    author_email character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.system_notes OWNER TO sapscope;

--
-- Name: user_clients; Type: TABLE; Schema: public; Owner: sapscope
--

CREATE TABLE public.user_clients (
    user_id uuid NOT NULL,
    client_id uuid NOT NULL
);


ALTER TABLE public.user_clients OWNER TO sapscope;

--
-- Name: users; Type: TABLE; Schema: public; Owner: sapscope
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    is_admin boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO sapscope;

--
-- Data for Name: agent_tokens; Type: TABLE DATA; Schema: public; Owner: sapscope
--

COPY public.agent_tokens (id, client_id, label, token_hash, created_at, is_revoked) FROM stdin;
5542e5e9-afc5-47c3-aeb6-13efc73fe4e6	f3e267a0-86cb-4ac5-adeb-af80b35595fb	test-agent	50ecf723c47ad6a8ba8f1d0e79974ebed51b1b62d8be7ec71f3441ad93d21885	2026-03-28 14:28:39.14477+00	f
2042cddb-ab3e-4a7e-80a7-29d6b642eb97	f3e267a0-86cb-4ac5-adeb-af80b35595fb	test2	cb79dc559d37a851968878a23beb5608e5d487cb7f283445f417e01cf1be42bb	2026-03-28 14:32:21.428585+00	f
dde51845-4189-4bff-a626-cd9505d2108d	f3e267a0-86cb-4ac5-adeb-af80b35595fb	test3	87266d846fad72b0a2e49d31e4594c89baa9c94e5b7c9c4809a3a02a6116e41d	2026-03-28 14:33:01.727036+00	f
3a28294f-8263-4860-8703-cf7d3324be47	f3e267a0-86cb-4ac5-adeb-af80b35595fb	bulk-inject	f2589ed49d66a09e524be2321468e2217b5e66d5e956ea3056fa00846f52f206	2026-03-28 14:46:11.937654+00	f
2e44b85a-d70d-4ed1-8710-71e068a40dbd	96011f52-5adc-4bec-a663-319d125760ee	agent-demo	a3f1c2d4e5b6789012345678901234567890abcdef1234567890abcdef123456	2026-03-28 22:17:15.618502+00	f
83c3ca40-5b51-4c44-b8fe-5037a0a00705	96011f52-5adc-4bec-a663-319d125760ee	agent-1774994519363	946e78461532fdcf4e83f4baedffd8dd31fcdf2ed854ec53b9552645403b4111	2026-03-31 22:01:59.430247+00	f
7812d985-ed3c-4eaa-9344-7cab4c4ba8ff	96011f52-5adc-4bec-a663-319d125760ee	default	6c2fca336986c3b032b4241d4d6074cd56fd349f14b52c127383cb976035649c	2026-04-29 13:57:48.134706+00	f
\.


--
-- Data for Name: analyses; Type: TABLE DATA; Schema: public; Owner: sapscope
--

COPY public.analyses (id, snapshot_id, model, input_tokens, output_tokens, content, created_at, language) FROM stdin;
49751dbf-06ae-4c14-9904-3b06ad2dab88	7d048cac-8a9d-42b4-a1e0-b22ab4e477b5	claude-sonnet-4-6	534	1546	## Release & Maintenance Status\n\nSAP NetWeaver / S/4HANA-adjacent stack at release **750** (ABAP Platform). SAP_BASIS 750 mainstream maintenance ended **31 December 2027** under the extended maintenance model, so the system is currently within mainstream support — no immediate deadline pressure, but the runway is finite.\n\nThe **kernel 777** is aging. SAP has released kernel 785 (long-term) and 793 as current patches. Kernel 777 reached end of life for patches; running it means known security and stability fixes are being missed. This is the most operationally urgent gap in the snapshot.\n\nGRC component suite (GRCFND_A / GRCPINW / GRC_BASIS) at release **1200** aligns with the 750 stack and is within its supported lifecycle.\n\n---\n\n## Support Package Currency\n\nBoth reported SP levels land at **SP 22, dated 2024-06-01**. That is roughly 12–14 months behind current as of mid-2025.\n\n- **SAP_BASIS 750**: Current stack is approximately SP 25–26. Lag is **3–4 SPs**.\n- **SAP_ABA 750**: Assumed aligned with BASIS at SP 22, same lag applies.\n- **SAP_UI 750 SP 18**: This is noticeably behind — SAP_UI moves faster and SP 18 is roughly **4–6 SPs** behind. SAP_UI gaps can affect Fiori and NWBC rendering, and SAP_UI patches frequently carry security fixes.\n- **GRC components at SP 22**: GRC 1200 SP stream has continued beyond SP 22; lag here carries compliance-tool-specific risk — missing bug fixes in AC, PC, or RM rule processing is operationally significant for a GRC production system.\n\n**Only 2 of 6 components are documented in the SP section.** No SP currency data is recorded for GRCPINW, GRC_BASIS, SAP_ABA, or SAP_UI. This is a reporting gap — the actual SP level for these must be confirmed.\n\n---\n\n## Custom Development Footprint\n\n**287 Z/Y objects** for a GRC-focused system is **moderate to heavy**. A typical GRC implementation leans on configuration and BAdIs rather than deep custom code; 287 objects suggests meaningful business-specific extensions or workarounds.\n\nType distribution observations:\n\n- **89 PROGs**: High proportion of standalone programs. Likely includes custom reports, data load utilities, or remediation automation. Needs review for redundancy and RFC-enabled risk.\n- **71 CLAS**: Substantial OO development. Generally a positive pattern (maintainable), but classes in a GRC context may be extending or bypassing standard GRC framework logic — warrants audit.\n- **54 FUGRs**: 54 function groups is significant. Each FUGR can contain many function modules, some potentially RFC-enabled. In a GRC system this is a security-relevant data point — RFC-enabled FMs sitting on a system holding authorisation and risk data need access control review.\n- **43 TABLs**: Custom tables at this volume suggest the team has built supplementary data models. Upgrade and migration risk increases with custom transparent/pooled tables.\n- **18 DTELs / 12 DOMAs**: Expected companion objects for the custom tables; not a concern in isolation.\n\nThe FUGR count relative to CLAS count is slightly inverted for modern development practices — indicates the codebase has older-style procedural layers alongside newer OO work.\n\n---\n\n## Key Risks\n\n1. **Kernel 777 out of patch support** — Security patches, memory management fixes, and HANA-specific kernel corrections since kernel 777 EOL are not applied. On a production GRC system (which holds sensitive authorisation and audit data), this is the highest-priority remediation. Upgrade to kernel 785 patch level or 793.\n\n2. **SAP_UI and GRC component SP lag** — SAP_UI SP 18 and undocumented GRC component SP levels create compounded exposure. SAP_UI gaps affect UI security headers and XSS fixes. GRC SP gaps may leave known rule-processing defects unresolved in a compliance-critical tool.\n\n3. **RFC-enabled function modules in 54 custom FUGRs** — A GRC system with high FUGR counts and custom code touching authorisation objects, risk rules, or user data needs a targeted RFC security scan. Unrestricted RFC access to this system is a critical audit finding waiting to happen.\n\n4. **Custom table volume (43 TABLs) and upgrade readiness** — Any future SP stack upgrade or migration to S/4HANA will require custom table compatibility checks, data migration planning, and potential adjustment of dependent programs and classes. The current footprint increases that effort materially.\n\n5. **Incomplete SP documentation** — 4 of 6 components have no recorded SP data in this snapshot. Operating a production GRC system without a complete, current SP inventory is itself an audit and change-management risk.\n\n---\n\n## Recommendations\n\n- **Immediate**: Plan kernel upgrade to 785 (long-term kernel) at the next available maintenance window. Test HANA connectivity and ICM behaviour post-upgrade — standard procedure but do not skip it.\n\n- **Within 30 days**: Complete the SP currency picture for all 6 components. Pull the full component list from transaction SPAM/SAINT and reconcile against SAP's maintenance planner.\n\n- **Within 60 days**: Run transaction RSRFCCHK and SE37 (RFC attribute review) across all custom FUGRs. Document and restrict any RFC-enabled FMs that do not have a justified business requirement, particularly those touching GRC data objects.\n\n- **Next maintenance cycle**: Target a full SP stack update bringing BASIS, ABA, SAP_UI, and GRC components to current levels. Use SAP Maintenance Planner to build a consistent SP stack — partial updates on a GRC system increase inconsistency risk.\n\n- **Medium term**: Commission a custom code review focused on the 89 PROGs and 54 FUGRs. Identify obsolete objects (GRC implementations often accumulate migration utilities that were never retired), flag any direct table access on GRC-owned tables, and rationalise the procedural/OO split.\n\n- **Planning horizon**: With BASIS 750 maintenance running to end-2027, initiate an upgrade scoping exercise now. Moving to ABAP Platform 7.57 / BTP or evaluating S/4HANA-based GRC options takes 12–24 months to execute properly on a production compliance system.	2026-04-23 23:28:11.491709+00	English
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: sapscope
--

COPY public.clients (id, name, created_at) FROM stdin;
f3e267a0-86cb-4ac5-adeb-af80b35595fb	Demo	2026-03-28 14:28:39.13213+00
96011f52-5adc-4bec-a663-319d125760ee	ACME Industries	2026-03-28 22:17:15.618502+00
\.


--
-- Data for Name: health_checks; Type: TABLE DATA; Schema: public; Owner: sapscope
--

COPY public.health_checks (id, snapshot_id, score, status, indicators, computed_at) FROM stdin;
9f7aae1a-025a-4871-bad3-785c8c4c64d3	5c54f277-28e7-4eba-b063-cc7c01612264	72	WARNING	{"security": {"score": 60, "status": "WARNING", "users_locked": 12}, "stability": {"score": 80, "status": "OK", "dumps_7d": 2, "jobs_aborted_7d": 0}, "performance": {"score": 70, "status": "WARNING", "wp_priv": 1, "wp_stopped": 0}, "connectivity": {"score": 100, "status": "OK", "trfc_errors": 0}, "infrastructure": {"score": 40, "status": "CRITICAL", "warning": ["PSAPSR3"], "critical": [], "max_used_pct": 85.1}}	2026-04-03 16:02:29.472302+00
261b9e2f-6ccf-4b38-9afa-69ad9c115145	012a4169-4d8b-4f6c-81db-cb8570cd5b5c	84	OK	{"security": {"score": 100, "status": "OK", "users_locked": 0}, "stability": {"score": 80, "status": "OK", "dumps_7d": 1, "jobs_aborted_7d": 1}, "performance": {"score": 70, "status": "WARNING", "wp_priv": 1, "wp_stopped": 0}, "connectivity": {"score": 80, "status": "OK", "trfc_errors": 2}, "infrastructure": {"score": 100, "status": "OK", "warning": [], "critical": [], "max_used_pct": 63.1}}	2026-04-03 16:02:29.472302+00
e8ebccae-3298-4a12-82db-87d7215abc11	d62b5c9d-0e8b-4bd2-99e3-fa820297562e	59	WARNING	{"security": {"score": 80, "status": "OK", "users_locked": 5}, "stability": {"score": 20, "status": "CRITICAL", "dumps_7d": 6, "jobs_aborted_7d": 5}, "performance": {"score": 70, "status": "WARNING", "wp_priv": 0, "wp_stopped": 1}, "connectivity": {"score": 100, "status": "OK", "trfc_errors": 0}, "infrastructure": {"score": 40, "status": "CRITICAL", "warning": ["PSAPTEMP"], "critical": ["PSAPSR3"], "max_used_pct": 91.5}}	2026-04-03 16:02:29.472302+00
50bc4a79-14f8-4ded-a7c0-2af474f2c049	b965729d-53f9-4c90-8b65-b17f58b293cb	78	WARNING	{"security": {"score": 80, "status": "OK", "users_locked": 7}, "stability": {"score": 80, "status": "OK", "dumps_7d": 2, "jobs_aborted_7d": 1}, "performance": {"score": 100, "status": "OK", "wp_priv": 0, "wp_stopped": 0}, "connectivity": {"score": 50, "status": "WARNING", "trfc_errors": 10}, "infrastructure": {"score": 75, "status": "WARNING", "warning": [], "critical": [], "max_used_pct": 76.4}}	2026-04-03 16:02:29.472302+00
a5f625b4-85ba-4177-ae94-031177507d0c	3d536510-ca77-4239-adbc-8e1122da5856	56	WARNING	{"security": {"score": 80, "status": "OK", "users_locked": 9}, "stability": {"score": 50, "status": "WARNING", "dumps_7d": 4, "jobs_aborted_7d": 0}, "performance": {"score": 40, "status": "CRITICAL", "wp_priv": 2, "wp_stopped": 0}, "connectivity": {"score": 50, "status": "WARNING", "trfc_errors": 15}, "infrastructure": {"score": 75, "status": "WARNING", "warning": ["PSAPTEMP"], "critical": [], "max_used_pct": 81.8}}	2026-04-03 16:02:29.472302+00
3cc3facd-221b-4ec1-ae96-2767c19891b5	5fee2b48-316c-44b1-a9d2-eafba6057dc6	86	OK	{"security": {"score": 80, "status": "OK", "users_locked": 4}, "stability": {"score": 80, "status": "OK", "dumps_7d": 2, "jobs_aborted_7d": 1}, "performance": {"score": 70, "status": "WARNING", "wp_priv": 1, "wp_stopped": 0}, "connectivity": {"score": 100, "status": "OK", "trfc_errors": 0}, "infrastructure": {"score": 100, "status": "OK", "warning": [], "critical": [], "max_used_pct": 72.7}}	2026-04-03 16:02:29.472302+00
2de78893-c42f-4ce9-8570-1b05f8e9da75	402ccc31-c27b-4839-8c9d-d86f802f4316	63	WARNING	{"security": {"score": 100, "status": "OK", "users_locked": 3}, "stability": {"score": 50, "status": "WARNING", "dumps_7d": 0, "jobs_aborted_7d": 3}, "performance": {"score": 40, "status": "CRITICAL", "wp_priv": 2, "wp_stopped": 0}, "connectivity": {"score": 50, "status": "WARNING", "trfc_errors": 10}, "infrastructure": {"score": 100, "status": "OK", "warning": [], "critical": [], "max_used_pct": 62.9}}	2026-04-03 16:02:29.472302+00
61d499a0-ae94-4dc7-aeef-f648629a0af0	73cef4a4-7594-4932-b588-fadf1c6fc5d7	78	WARNING	{"security": {"score": 80, "status": "OK", "users_locked": 9}, "stability": {"score": 20, "status": "CRITICAL", "dumps_7d": 8, "jobs_aborted_7d": 1}, "performance": {"score": 100, "status": "OK", "wp_priv": 0, "wp_stopped": 0}, "connectivity": {"score": 100, "status": "OK", "trfc_errors": 0}, "infrastructure": {"score": 100, "status": "OK", "warning": [], "critical": [], "max_used_pct": 62.0}}	2026-04-03 16:02:29.472302+00
06867f45-eacc-48b1-88e5-96bd91144dd2	54eafbb4-ffe1-48f4-8a26-318c90de3b0b	73	WARNING	{"security": {"score": 100, "status": "OK", "users_locked": 1}, "stability": {"score": 20, "status": "CRITICAL", "dumps_7d": 7, "jobs_aborted_7d": 1}, "performance": {"score": 70, "status": "WARNING", "wp_priv": 1, "wp_stopped": 0}, "connectivity": {"score": 100, "status": "OK", "trfc_errors": 0}, "infrastructure": {"score": 100, "status": "OK", "warning": [], "critical": [], "max_used_pct": 71.5}}	2026-04-03 16:02:29.472302+00
bd237319-7082-4702-b88f-f85cacee7d2a	7d048cac-8a9d-42b4-a1e0-b22ab4e477b5	65	WARNING	{"security": {"score": 100, "status": "OK", "users_locked": 1}, "stability": {"score": 80, "status": "OK", "dumps_7d": 1, "jobs_aborted_7d": 0}, "performance": {"score": 40, "status": "CRITICAL", "wp_priv": 1, "wp_stopped": 1}, "connectivity": {"score": 50, "status": "WARNING", "trfc_errors": 12}, "infrastructure": {"score": 75, "status": "WARNING", "warning": [], "critical": [], "max_used_pct": 75.3}}	2026-04-03 16:02:29.472302+00
f7872556-34a4-4727-ac6b-71d31ff3fb0c	3132e5e0-d5f6-4cc1-a61c-9af10b103be9	52	WARNING	{"security": {"score": 100, "status": "OK", "users_locked": 0}, "stability": {"score": 50, "status": "WARNING", "dumps_7d": 1, "jobs_aborted_7d": 4}, "performance": {"score": 70, "status": "WARNING", "wp_priv": 1, "wp_stopped": 0}, "connectivity": {"score": 20, "status": "CRITICAL", "trfc_errors": 25}, "infrastructure": {"score": 40, "status": "CRITICAL", "warning": ["PSAPSR3"], "critical": [], "max_used_pct": 87.8}}	2026-04-03 16:02:29.472302+00
9165a43c-935f-41d5-8a5e-e576ecb8fc9b	e4577de3-5f63-49b2-a7bf-e2ae9b0a7fc3	71	WARNING	{"security": {"score": 100, "status": "OK", "users_locked": 3}, "stability": {"score": 100, "status": "OK", "dumps_7d": 0, "jobs_aborted_7d": 0}, "performance": {"score": 70, "status": "WARNING", "wp_priv": 1, "wp_stopped": 0}, "connectivity": {"score": 80, "status": "OK", "trfc_errors": 5}, "infrastructure": {"score": 10, "status": "CRITICAL", "warning": [], "critical": ["PSAPSR3"], "max_used_pct": 92.9}}	2026-04-03 16:02:29.472302+00
36cb8be4-1d40-47db-891f-94024e35441f	da583df3-87c6-44e5-a83b-7d4e0b38f9d1	78	WARNING	{"security": {"score": 100, "status": "OK", "users_locked": 3}, "stability": {"score": 100, "status": "OK", "dumps_7d": 0, "jobs_aborted_7d": 0}, "performance": {"score": 70, "status": "WARNING", "wp_priv": 1, "wp_stopped": 0}, "connectivity": {"score": 50, "status": "WARNING", "trfc_errors": 12}, "infrastructure": {"score": 75, "status": "WARNING", "warning": ["PSAPSR3"], "critical": [], "max_used_pct": 84.1}}	2026-04-03 16:02:29.472302+00
c019bffa-79e2-44bf-8224-420388959f67	4d5be6d4-ffa4-4b06-95a7-fed3cab9f321	95	OK	{"security": {"score": 100, "status": "OK", "users_locked": 1}, "stability": {"score": 80, "status": "OK", "dumps_7d": 0, "jobs_aborted_7d": 1}, "performance": {"score": 100, "status": "OK", "wp_priv": 0, "wp_stopped": 0}, "connectivity": {"score": 100, "status": "OK", "trfc_errors": 0}, "infrastructure": {"score": 100, "status": "OK", "warning": [], "critical": [], "max_used_pct": 59.9}}	2026-04-03 16:02:29.472302+00
e1f8962b-63cb-4db6-a8cc-730f781aba67	6a637ec1-050f-41ac-b012-bb089febea99	63	WARNING	{"security": {"score": 80, "status": "OK", "users_locked": 7}, "stability": {"score": 50, "status": "WARNING", "dumps_7d": 3, "jobs_aborted_7d": 0}, "performance": {"score": 70, "status": "WARNING", "wp_priv": 1, "wp_stopped": 0}, "connectivity": {"score": 50, "status": "WARNING", "trfc_errors": 12}, "infrastructure": {"score": 75, "status": "WARNING", "warning": [], "critical": [], "max_used_pct": 75.3}}	2026-04-03 16:02:29.472302+00
\.


--
-- Data for Name: licenses; Type: TABLE DATA; Schema: public; Owner: sapscope
--

COPY public.licenses (id, key, email, plan, expires_at, activated_at, instance_id, active, created_at) FROM stdin;
\.


--
-- Data for Name: onboarding_tokens; Type: TABLE DATA; Schema: public; Owner: sapscope
--

COPY public.onboarding_tokens (id, user_id, client_id, token_plaintext, created_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: sapscope
--

COPY public.password_reset_tokens (id, user_id, token_hash, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: snapshots; Type: TABLE DATA; Schema: public; Owner: sapscope
--

COPY public.snapshots (id, client_id, system_sid, system_host, schema_version, collected_at, received_at, payload) FROM stdin;
5c54f277-28e7-4eba-b063-cc7c01612264	f3e267a0-86cb-4ac5-adeb-af80b35595fb	RTR	saprouter-prd.corp.local	1.0	2026-03-28 10:45:00+00	2026-03-28 14:46:11.967629+00	{"system": {"rfchost": "saprouter-prd.corp.local", "rfcdbsys": "", "rfcopsys": "Linux", "rfcsaprl": "756", "rfcsysid": "RTR", "rfcdbhost": "", "rfckernrl": "789"}, "components": [{"release": "756", "component": "SAP_BASIS", "extrelease": "0018"}, {"release": "756", "component": "SAPROUTER", "extrelease": "0012"}], "collected_at": "2026-03-28T10:45:00Z", "custom_objects": {"total": 0, "by_type": {}}, "schema_version": "1.0", "support_packages": [{"patch": "SAPKB75618", "applied": "20260101", "component": "SAP_BASIS"}, {"patch": "SAPKB75612R", "applied": "20260101", "component": "SAPROUTER"}]}
012a4169-4d8b-4f6c-81db-cb8570cd5b5c	f3e267a0-86cb-4ac5-adeb-af80b35595fb	PRD	sap-prd-01.demo.local	1.0	2026-03-28 10:00:00+00	2026-03-28 14:33:01.742081+00	{"system": {"rfchost": "sap-prd-01.demo.local", "rfcmach": "x86_64", "rfcdayst": "X", "rfcdbsys": "HANA", "rfcopsys": "Linux", "rfcsaprl": "756", "rfcsysid": "PRD", "rfctzone": "3600", "rfcdbhost": "hana-prd.corp.local", "rfcipaddr": "10.10.1.10", "rfckernrl": "785"}, "components": [{"release": "756", "component": "SAP_BASIS", "extrelease": "0014"}, {"release": "756", "component": "SAP_ABA", "extrelease": "0014"}, {"release": "606", "component": "SAP_APPL", "extrelease": "0022"}], "collected_at": "2026-03-28T10:00:00Z", "custom_objects": {"total": 12450, "by_type": {"CLAS": 980, "FUGR": 1800, "PROG": 3200, "TABL": 750}}, "schema_version": "1.0", "support_packages": [{"patch": "SAPKB75614", "applied": "20250901", "component": "SAP_BASIS"}, {"patch": "SAPKA75614", "applied": "20250901", "component": "SAP_ABA"}]}
d62b5c9d-0e8b-4bd2-99e3-fa820297562e	96011f52-5adc-4bec-a663-319d125760ee	RTR	saprouter-prd.acme.local	1	2026-03-28 22:12:15.618502+00	2026-03-28 22:17:15.618502+00	{"system": {"rfchost": "saprouter-prd.acme.local", "rfcmach": "x86_64", "rfcdayst": "X", "rfcdbsys": "", "rfcopsys": "Linux", "rfcsaprl": "753", "rfcsysid": "RTR", "rfctzone": "3600", "rfcdbhost": "", "rfcipaddr": "10.0.0.1", "rfckernrl": "753", "rfcipv6addr": "2001:db8::1"}, "components": [{"release": "753", "component": "SAP_BASIS", "extrelease": "0000", "description": "SAP Basis Component (standalone NW)"}], "collected_at": "2026-03-28T08:05:00+00:00", "custom_objects": {"total": 0, "by_type": {}, "objects": []}, "schema_version": "1", "support_packages": []}
b965729d-53f9-4c90-8b65-b17f58b293cb	f3e267a0-86cb-4ac5-adeb-af80b35595fb	DEV	sap-dev-01.corp.local	1.0	2026-03-28 09:00:00+00	2026-03-28 14:46:11.944819+00	{"system": {"rfchost": "sap-dev-01.corp.local", "rfcmach": "x86_64", "rfcdayst": "X", "rfcdbsys": "HANA", "rfcopsys": "Linux", "rfcsaprl": "756", "rfcsysid": "DEV", "rfctzone": "3600", "rfcdbhost": "hana-dev.corp.local", "rfcipaddr": "10.10.1.20", "rfckernrl": "785"}, "components": [{"release": "756", "component": "SAP_BASIS", "extrelease": "0014"}, {"release": "756", "component": "SAP_ABA", "extrelease": "0014"}, {"release": "606", "component": "SAP_APPL", "extrelease": "0022"}, {"release": "606", "component": "SAP_HR", "extrelease": "0018"}, {"release": "606", "component": "EA-FINSERV", "extrelease": "0012"}, {"release": "756", "component": "SAP_BW", "extrelease": "0008"}], "collected_at": "2026-03-28T09:00:00Z", "custom_objects": {"total": 28740, "by_type": {"BADI": 480, "CLAS": 2200, "DOMA": 1400, "DTEL": 1300, "ENHO": 750, "FUGR": 3900, "IDOC": 290, "MSAG": 390, "PROG": 7800, "SMIM": 90, "SMOD": 620, "TABL": 1850, "TTYP": 310, "VIEW": 980, "WDYN": 180}}, "schema_version": "1.0", "support_packages": [{"patch": "SAPKB75614", "applied": "20240601", "component": "SAP_BASIS"}, {"patch": "SAPKA75614", "applied": "20240601", "component": "SAP_ABA"}, {"patch": "SAPKH60622", "applied": "20240101", "component": "SAP_APPL"}]}
3d536510-ca77-4239-adbc-8e1122da5856	f3e267a0-86cb-4ac5-adeb-af80b35595fb	QAL	sap-qal-01.corp.local	1.0	2026-03-28 09:30:00+00	2026-03-28 14:46:11.952179+00	{"system": {"rfchost": "sap-qal-01.corp.local", "rfcmach": "x86_64", "rfcdayst": "X", "rfcdbsys": "HANA", "rfcopsys": "Linux", "rfcsaprl": "756", "rfcsysid": "QAL", "rfctzone": "3600", "rfcdbhost": "hana-qal.corp.local", "rfcipaddr": "10.10.1.30", "rfckernrl": "785"}, "components": [{"release": "756", "component": "SAP_BASIS", "extrelease": "0016"}, {"release": "756", "component": "SAP_ABA", "extrelease": "0016"}, {"release": "606", "component": "SAP_APPL", "extrelease": "0022"}, {"release": "606", "component": "SAP_HR", "extrelease": "0020"}, {"release": "606", "component": "EA-FINSERV", "extrelease": "0014"}, {"release": "756", "component": "SAP_BW", "extrelease": "0010"}], "collected_at": "2026-03-28T09:30:00Z", "custom_objects": {"total": 18920, "by_type": {"BADI": 380, "CLAS": 1700, "DOMA": 1100, "DTEL": 980, "ENHO": 610, "FUGR": 2800, "IDOC": 210, "MSAG": 290, "PROG": 5100, "SMOD": 490, "TABL": 1400, "TTYP": 240, "VIEW": 740}}, "schema_version": "1.0", "support_packages": [{"patch": "SAPKB75616", "applied": "20250601", "component": "SAP_BASIS"}, {"patch": "SAPKA75616", "applied": "20250601", "component": "SAP_ABA"}, {"patch": "SAPKH60622", "applied": "20250301", "component": "SAP_APPL"}, {"patch": "SAPKE60620", "applied": "20250101", "component": "SAP_HR"}]}
5fee2b48-316c-44b1-a9d2-eafba6057dc6	96011f52-5adc-4bec-a663-319d125760ee	PRD	sapprdhst01	1	2026-03-28 22:07:15.618502+00	2026-03-28 22:17:15.618502+00	{"system": {"rfchost": "sapprdhst01", "rfcmach": "x86_64", "rfcdayst": "X", "rfcdbsys": "ORA", "rfcopsys": "Linux", "rfcsaprl": "618", "rfcsysid": "PRD", "rfctzone": "3600", "rfcdbhost": "db-ora-prd01.acme.local", "rfcipaddr": "10.0.1.10", "rfckernrl": "753", "rfcipv6addr": ""}, "components": [{"release": "702", "component": "SAP_BASIS", "extrelease": "0018", "description": "SAP Basis Component"}, {"release": "702", "component": "SAP_ABA", "extrelease": "0018", "description": "Cross-Application Component"}, {"release": "618", "component": "SAP_APPL", "extrelease": "0000", "description": "Logistics and Accounting"}, {"release": "608", "component": "SAP_HR", "extrelease": "0018", "description": "Human Resources"}, {"release": "618", "component": "SAP_FIN", "extrelease": "0000", "description": "SAP Financial Accounting"}, {"release": "608", "component": "SAP_HRRXX", "extrelease": "0018", "description": "SAP HR Addon"}, {"release": "702", "component": "SAP_AP", "extrelease": "0018", "description": "Application Platform"}, {"release": "400", "component": "EA-IPPE", "extrelease": "0018", "description": "Integrated Product and Process Eng."}, {"release": "618", "component": "EA-RETAIL", "extrelease": "0000", "description": "SAP for Retail"}, {"release": "702", "component": "TOOLSAP", "extrelease": "0018", "description": "Tools for SAP"}], "collected_at": "2026-03-28T08:00:00+00:00", "custom_objects": {"total": 1847, "by_type": {"CLAS": 201, "DOMA": 89, "DTEL": 156, "FORM": 211, "FUGR": 318, "PROG": 642, "TABL": 187, "TTYP": 43}, "objects": [{"lang": "FR", "name": "ZFICO_REPORT_BALANCE", "type": "PROG", "author": "LECLERCF", "origin": "C", "created": "20190312", "package": "ZFICO"}, {"lang": "FR", "name": "ZLOGISTIC_STOCK_DAILY", "type": "PROG", "author": "DUPONTM", "origin": "C", "created": "20200601", "package": "ZMM"}, {"lang": "FR", "name": "ZRFC_INTERCO_PAYMENTS", "type": "FUGR", "author": "LECLERCF", "origin": "C", "created": "20180415", "package": "ZFICO"}, {"lang": "FR", "name": "ZCL_IDOC_PARSER", "type": "CLAS", "author": "MARTINB", "origin": "C", "created": "20210720", "package": "ZEDI"}, {"lang": "FR", "name": "ZACME_CUSTOMER_EXT", "type": "TABL", "author": "BLANCP", "origin": "C", "created": "20170210", "package": "ZCUST"}]}, "schema_version": "1", "support_packages": [{"time": "120000", "type": "Support Package", "patch": "SAPKB70218", "applied": "20240115", "component": "SAP_BASIS"}, {"time": "123000", "type": "Support Package", "patch": "SAPKA70218", "applied": "20240115", "component": "SAP_ABA"}, {"time": "090000", "type": "Support Package", "patch": "SAPKH61800", "applied": "20231020", "component": "SAP_APPL"}, {"time": "091500", "type": "Support Package", "patch": "SAPKH60818", "applied": "20231020", "component": "SAP_HR"}]}
402ccc31-c27b-4839-8c9d-d86f802f4316	96011f52-5adc-4bec-a663-319d125760ee	DEV	sapdevhst01	1	2026-03-28 22:08:15.618502+00	2026-03-28 22:17:15.618502+00	{"system": {"rfchost": "sapdevhst01", "rfcmach": "x86_64", "rfcdayst": "X", "rfcdbsys": "HDB", "rfcopsys": "Linux", "rfcsaprl": "750", "rfcsysid": "DEV", "rfctzone": "3600", "rfcdbhost": "hana-dev01.acme.local", "rfcipaddr": "10.0.1.20", "rfckernrl": "777", "rfcipv6addr": ""}, "components": [{"release": "750", "component": "SAP_BASIS", "extrelease": "0027", "description": "SAP Basis Component"}, {"release": "750", "component": "SAP_ABA", "extrelease": "0027", "description": "Cross-Application Component"}, {"release": "618", "component": "SAP_APPL", "extrelease": "0000", "description": "Logistics and Accounting"}, {"release": "750", "component": "SAP_UI", "extrelease": "0023", "description": "SAP UI Technologies"}, {"release": "608", "component": "SAP_HR", "extrelease": "0018", "description": "Human Resources"}, {"release": "100", "component": "UIAPFI70", "extrelease": "0018", "description": "Fiori Apps for Finance"}], "collected_at": "2026-03-28T08:01:00+00:00", "custom_objects": {"total": 2341, "by_type": {"CLAS": 287, "DOMA": 112, "DTEL": 198, "FORM": 178, "FUGR": 402, "INTF": 143, "PROG": 798, "TABL": 223}, "objects": [{"lang": "FR", "name": "ZDEV_TEST_HARNESS", "type": "PROG", "author": "RICHARDV", "origin": "C", "created": "20220901", "package": "ZTOOLS"}, {"lang": "FR", "name": "ZCL_REST_CLIENT", "type": "CLAS", "author": "RICHARDV", "origin": "C", "created": "20230115", "package": "ZINTEGR"}, {"lang": "FR", "name": "ZIF_PAYMENT_GATEWAY", "type": "INTF", "author": "LECLERCF", "origin": "C", "created": "20240210", "package": "ZFICO"}, {"lang": "FR", "name": "ZDEV_CONFIG", "type": "TABL", "author": "MARTINB", "origin": "C", "created": "20211130", "package": "ZTOOLS"}]}, "schema_version": "1", "support_packages": [{"time": "020000", "type": "Support Package", "patch": "SAPKB75027", "applied": "20250301", "component": "SAP_BASIS"}, {"time": "022000", "type": "Support Package", "patch": "SAPKA75027", "applied": "20250301", "component": "SAP_ABA"}, {"time": "030000", "type": "Support Package", "patch": "SAPKIIFZAD", "applied": "20250301", "component": "SAP_UI"}]}
73cef4a4-7594-4932-b588-fadf1c6fc5d7	96011f52-5adc-4bec-a663-319d125760ee	QAS	sapqashst01	1	2026-03-28 22:09:15.618502+00	2026-03-28 22:17:15.618502+00	{"system": {"rfchost": "sapqashst01", "rfcmach": "x86_64", "rfcdayst": "X", "rfcdbsys": "HDB", "rfcopsys": "Linux", "rfcsaprl": "750", "rfcsysid": "QAS", "rfctzone": "3600", "rfcdbhost": "hana-qas01.acme.local", "rfcipaddr": "10.0.1.30", "rfckernrl": "777", "rfcipv6addr": ""}, "components": [{"release": "750", "component": "SAP_BASIS", "extrelease": "0025", "description": "SAP Basis Component"}, {"release": "750", "component": "SAP_ABA", "extrelease": "0025", "description": "Cross-Application Component"}, {"release": "618", "component": "SAP_APPL", "extrelease": "0000", "description": "Logistics and Accounting"}, {"release": "750", "component": "SAP_UI", "extrelease": "0021", "description": "SAP UI Technologies"}, {"release": "608", "component": "SAP_HR", "extrelease": "0016", "description": "Human Resources"}], "collected_at": "2026-03-28T08:02:00+00:00", "custom_objects": {"total": 1832, "by_type": {"CLAS": 278, "DOMA": 107, "DTEL": 192, "FUGR": 396, "PROG": 641, "TABL": 218}, "objects": [{"lang": "FR", "name": "ZTEST_INTEGRATION_SD", "type": "PROG", "author": "DUPONTM", "origin": "C", "created": "20230401", "package": "ZSD"}, {"lang": "FR", "name": "ZCL_REST_CLIENT", "type": "CLAS", "author": "RICHARDV", "origin": "C", "created": "20230115", "package": "ZINTEGR"}, {"lang": "FR", "name": "ZQAS_BATCH_CHECK", "type": "PROG", "author": "MARTINB", "origin": "C", "created": "20240601", "package": "ZTOOLS"}]}, "schema_version": "1", "support_packages": [{"time": "020000", "type": "Support Package", "patch": "SAPKB75025", "applied": "20241001", "component": "SAP_BASIS"}, {"time": "021500", "type": "Support Package", "patch": "SAPKA75025", "applied": "20241001", "component": "SAP_ABA"}, {"time": "090000", "type": "Support Package", "patch": "SAPKH61800", "applied": "20231020", "component": "SAP_APPL"}]}
54eafbb4-ffe1-48f4-8a26-318c90de3b0b	96011f52-5adc-4bec-a663-319d125760ee	SRM	sap-srm-prd.acme.local	1	2026-03-28 22:10:15.618502+00	2026-03-28 22:17:15.618502+00	{"system": {"rfchost": "sap-srm-prd.acme.local", "rfcmach": "x86_64", "rfcdayst": "X", "rfcdbsys": "ORA", "rfcopsys": "Linux", "rfcsaprl": "731", "rfcsysid": "SRM", "rfctzone": "3600", "rfcdbhost": "sap-srm-prd.acme.local", "rfcipaddr": "10.0.1.40", "rfckernrl": "753", "rfcipv6addr": ""}, "components": [{"release": "731", "component": "SAP_BASIS", "extrelease": "0014", "description": "SAP Basis Component"}, {"release": "731", "component": "SAP_ABA", "extrelease": "0014", "description": "Cross-Application Component"}, {"release": "700", "component": "SRM_SERVER", "extrelease": "0014", "description": "SRM Server"}, {"release": "700", "component": "BBPCRM", "extrelease": "0014", "description": "SRM / CRM Shared Objects"}, {"release": "700", "component": "SAP_AP", "extrelease": "0014", "description": "Application Platform"}], "collected_at": "2026-03-28T08:03:00+00:00", "custom_objects": {"total": 412, "by_type": {"CLAS": 67, "DOMA": 24, "DTEL": 34, "FUGR": 98, "PROG": 134, "TABL": 55}, "objects": [{"lang": "FR", "name": "ZSRM_CATALOG_SYNC", "type": "PROG", "author": "BLANCP", "origin": "C", "created": "20180920", "package": "ZSRM"}, {"lang": "FR", "name": "ZSRM_RFC_SUPPLIER", "type": "FUGR", "author": "BLANCP", "origin": "C", "created": "20190314", "package": "ZSRM"}]}, "schema_version": "1", "support_packages": [{"time": "020000", "type": "Support Package", "patch": "SAPKB73114", "applied": "20220610", "component": "SAP_BASIS"}, {"time": "030000", "type": "Support Package", "patch": "SAPKIBK7014", "applied": "20220610", "component": "SRM_SERVER"}]}
7d048cac-8a9d-42b4-a1e0-b22ab4e477b5	96011f52-5adc-4bec-a663-319d125760ee	GRC	sap-grc-prd.acme.local	1	2026-03-28 22:11:15.618502+00	2026-03-28 22:17:15.618502+00	{"system": {"rfchost": "sap-grc-prd.acme.local", "rfcmach": "x86_64", "rfcdayst": "X", "rfcdbsys": "HDB", "rfcopsys": "Linux", "rfcsaprl": "750", "rfcsysid": "GRC", "rfctzone": "3600", "rfcdbhost": "sap-grc-prd.acme.local", "rfcipaddr": "10.0.1.50", "rfckernrl": "777", "rfcipv6addr": ""}, "components": [{"release": "750", "component": "SAP_BASIS", "extrelease": "0022", "description": "SAP Basis Component"}, {"release": "750", "component": "SAP_ABA", "extrelease": "0022", "description": "Cross-Application Component"}, {"release": "1200", "component": "GRCFND_A", "extrelease": "0022", "description": "GRC Foundation Application"}, {"release": "1200", "component": "GRC_BASIS", "extrelease": "0022", "description": "GRC Foundation Basis"}, {"release": "1200", "component": "GRCPINW", "extrelease": "0022", "description": "GRC Process Integration"}, {"release": "750", "component": "SAP_UI", "extrelease": "0018", "description": "SAP UI Technologies"}], "collected_at": "2026-03-28T08:04:00+00:00", "custom_objects": {"total": 287, "by_type": {"CLAS": 71, "DOMA": 12, "DTEL": 18, "FUGR": 54, "PROG": 89, "TABL": 43}, "objects": [{"lang": "FR", "name": "ZGRC_SOD_REPORT", "type": "PROG", "author": "LECLERCF", "origin": "C", "created": "20211005", "package": "ZGRC"}, {"lang": "FR", "name": "ZCL_GRC_ROLE_UTIL", "type": "CLAS", "author": "MARTINB", "origin": "C", "created": "20220310", "package": "ZGRC"}]}, "schema_version": "1", "support_packages": [{"time": "020000", "type": "Support Package", "patch": "SAPKB75022", "applied": "20240601", "component": "SAP_BASIS"}, {"time": "040000", "type": "Support Package", "patch": "SAPK-12022INGRCFNDA", "applied": "20240601", "component": "GRCFND_A"}]}
3132e5e0-d5f6-4cc1-a61c-9af10b103be9	96011f52-5adc-4bec-a663-319d125760ee	BWA	sap-bwa-prd.acme.local	1	2026-03-28 22:30:31.843555+00	2026-03-28 22:32:31.843555+00	{"system": {"rfchost": "sap-bwa-prd.acme.local", "rfcmach": "x86_64", "rfcdayst": "X", "rfcdbsys": "HDB", "rfcopsys": "Linux", "rfcsaprl": "750", "rfcsysid": "BWA", "rfctzone": "3600", "rfcdbhost": "hana-bwa01.acme.local", "rfcipaddr": "10.0.1.60", "rfckernrl": "777", "rfcipv6addr": ""}, "components": [{"release": "750", "component": "SAP_BASIS", "extrelease": "0024", "description": "SAP Basis Component"}, {"release": "750", "component": "SAP_ABA", "extrelease": "0024", "description": "Cross-Application Component"}, {"release": "750", "component": "SAP_BW", "extrelease": "0024", "description": "SAP Business Warehouse"}, {"release": "757", "component": "BI_CONT", "extrelease": "0008", "description": "Business Intelligence Content"}, {"release": "750", "component": "SAP_UI", "extrelease": "0020", "description": "SAP UI Technologies"}, {"release": "101", "component": "BWMIGR", "extrelease": "0008", "description": "BW Migration Cockpit"}], "collected_at": "2026-03-28T08:08:00+00:00", "custom_objects": {"total": 891, "by_type": {"DSO": 143, "CUBE": 78, "IOBJ": 187, "ODSO": 47, "PROG": 134, "ROUT": 213, "TRFN": 89}, "objects": [{"lang": "FR", "name": "ZACME_FI_AR_ROUTE", "type": "ROUT", "author": "LECLERCF", "origin": "C", "created": "20190801", "package": "ZBWFI"}, {"lang": "FR", "name": "ZACME_SALES_ANALYSIS", "type": "CUBE", "author": "DUPONTM", "origin": "C", "created": "20200315", "package": "ZBWSD"}, {"lang": "FR", "name": "ZACME_DIVISION_CODE", "type": "IOBJ", "author": "BLANCP", "origin": "C", "created": "20180620", "package": "ZBWMM"}, {"lang": "FR", "name": "ZACME_BW_DELTA_MONITOR", "type": "PROG", "author": "MARTINB", "origin": "C", "created": "20230110", "package": "ZBWBASIS"}]}, "schema_version": "1", "support_packages": [{"time": "020000", "type": "Support Package", "patch": "SAPKB75024", "applied": "20240301", "component": "SAP_BASIS"}, {"time": "040000", "type": "Support Package", "patch": "SAPKW75024", "applied": "20240301", "component": "SAP_BW"}, {"time": "060000", "type": "Support Package", "patch": "SAPKIBIIP8", "applied": "20231001", "component": "BI_CONT"}]}
da583df3-87c6-44e5-a83b-7d4e0b38f9d1	f3e267a0-86cb-4ac5-adeb-af80b35595fb	ADS	sap-ads-prd.corp.local	1.0	2026-03-28 10:30:00+00	2026-03-28 14:46:11.959155+00	{"system": {"rfchost": "sap-ads-prd.corp.local", "rfcmach": "x86_64", "rfcdayst": "X", "rfcdbsys": "MaxDB", "rfcopsys": "Linux", "rfcsaprl": "756", "rfcsysid": "ADS", "rfctzone": "3600", "rfcdbhost": "sap-ads-01.corp.local", "rfcipaddr": "10.10.1.50", "rfckernrl": "789"}, "components": [{"release": "756", "component": "SAP_BASIS", "extrelease": "0018"}, {"release": "756", "component": "SAP_ABA", "extrelease": "0018"}, {"release": "756", "component": "ADS", "extrelease": "0006"}, {"release": "756", "component": "SAP_ADSV", "extrelease": "0004"}], "collected_at": "2026-03-28T10:30:00Z", "custom_objects": {"total": 180, "by_type": {"CLAS": 21, "DOMA": 18, "DTEL": 17, "FUGR": 28, "PROG": 62, "TABL": 34}}, "schema_version": "1.0", "support_packages": [{"patch": "SAPKB75618", "applied": "20251201", "component": "SAP_BASIS"}, {"patch": "SAPKA75618", "applied": "20251201", "component": "SAP_ABA"}, {"patch": "SAPK-75606A", "applied": "20251001", "component": "ADS"}]}
4d5be6d4-ffa4-4b06-95a7-fed3cab9f321	f3e267a0-86cb-4ac5-adeb-af80b35595fb	BWP	sap-bwp-prd.corp.local	1	2026-03-28 22:28:31.843555+00	2026-03-28 22:32:31.843555+00	{"system": {"rfchost": "sap-bwp-prd.corp.local", "rfcmach": "x86_64", "rfcdayst": "X", "rfcdbsys": "HDB", "rfcopsys": "Linux", "rfcsaprl": "757", "rfcsysid": "BWP", "rfctzone": "3600", "rfcdbhost": "hana-bwp.corp.local", "rfcipaddr": "10.10.1.60", "rfckernrl": "789", "rfcipv6addr": ""}, "components": [{"release": "757", "component": "SAP_BASIS", "extrelease": "0003", "description": "SAP Basis Component"}, {"release": "757", "component": "SAP_ABA", "extrelease": "0003", "description": "Cross-Application Component"}, {"release": "758", "component": "BI_CONT", "extrelease": "0003", "description": "Business Intelligence Content"}, {"release": "757", "component": "SAP_BW", "extrelease": "0003", "description": "SAP BW/4HANA"}, {"release": "200", "component": "BW4CORE", "extrelease": "0003", "description": "BW/4HANA Core"}, {"release": "200", "component": "HANA_BI", "extrelease": "0003", "description": "SAP HANA BI Platform"}, {"release": "757", "component": "SAP_UI", "extrelease": "0002", "description": "SAP UI Technologies"}], "collected_at": "2026-03-28T08:06:00+00:00", "custom_objects": {"total": 523, "by_type": {"DSO": 67, "CUBE": 34, "IOBJ": 78, "ODSO": 35, "PROG": 112, "ROUT": 89, "TRAN": 43, "TRFN": 65}, "objects": [{"lang": "EN", "name": "ZDEMO_FINANCE_ROUTE", "type": "ROUT", "author": "THOUVARD", "origin": "C", "created": "20230601", "package": "ZBWFI"}, {"lang": "EN", "name": "ZDEMO_SALES_CUBE", "type": "CUBE", "author": "THOUVARD", "origin": "C", "created": "20220315", "package": "ZBWSD"}, {"lang": "EN", "name": "ZDEMO_MATERIAL_GRPG", "type": "IOBJ", "author": "NGUYEN", "origin": "C", "created": "20210820", "package": "ZBWMM"}, {"lang": "EN", "name": "ZDEMO_BW_LOAD_MONITOR", "type": "PROG", "author": "THOUVARD", "origin": "C", "created": "20240110", "package": "ZBWBASIS"}]}, "schema_version": "1", "support_packages": [{"time": "030000", "type": "Support Package", "patch": "SAPKB75703", "applied": "20260101", "component": "SAP_BASIS"}, {"time": "031500", "type": "Support Package", "patch": "SAPKA75703", "applied": "20260101", "component": "SAP_ABA"}, {"time": "050000", "type": "Support Package", "patch": "SAPK-20003INBW4CORE", "applied": "20260101", "component": "BW4CORE"}, {"time": "060000", "type": "Support Package", "patch": "SAPKIBIIP8", "applied": "20251001", "component": "BI_CONT"}]}
6a637ec1-050f-41ac-b012-bb089febea99	f3e267a0-86cb-4ac5-adeb-af80b35595fb	PI1	sap-pi1-prd.corp.local	1	2026-03-28 22:29:31.843555+00	2026-03-28 22:32:31.843555+00	{"system": {"rfchost": "sap-pi1-prd.corp.local", "rfcmach": "x86_64", "rfcdayst": "X", "rfcdbsys": "ORA", "rfcopsys": "Linux", "rfcsaprl": "750", "rfcsysid": "PI1", "rfctzone": "3600", "rfcdbhost": "ora-pi.corp.local", "rfcipaddr": "10.10.1.70", "rfckernrl": "777", "rfcipv6addr": ""}, "components": [{"release": "750", "component": "SAP_BASIS", "extrelease": "0026", "description": "SAP Basis Component"}, {"release": "750", "component": "SAP_ABA", "extrelease": "0026", "description": "Cross-Application Component"}, {"release": "750", "component": "PI_BASIS", "extrelease": "0026", "description": "SAP PI / Process Integration Basis"}, {"release": "750", "component": "XIESR", "extrelease": "0026", "description": "Enterprise Services Repository"}, {"release": "750", "component": "XITOOL", "extrelease": "0026", "description": "Integration Builder Tools"}, {"release": "750", "component": "XIAF", "extrelease": "0026", "description": "Advanced Adapter Framework"}, {"release": "750", "component": "XIRWB", "extrelease": "0026", "description": "Integration Workbench"}, {"release": "750", "component": "SAP_UI", "extrelease": "0021", "description": "SAP UI Technologies"}], "collected_at": "2026-03-28T08:07:00+00:00", "custom_objects": {"total": 318, "by_type": {"CLAS": 54, "DTEL": 29, "INTF": 48, "PROG": 62, "SWFL": 87, "TABL": 38}, "objects": [{"lang": "EN", "name": "ZDEMO_IDOC_TO_VENDOR", "type": "SWFL", "author": "MOULIN", "origin": "C", "created": "20220401", "package": "ZPISD"}, {"lang": "EN", "name": "ZCL_PI_MSG_TRANSFORM", "type": "CLAS", "author": "MOULIN", "origin": "C", "created": "20230715", "package": "ZPIBASE"}, {"lang": "EN", "name": "ZDEMO_PI_REPROCESS", "type": "PROG", "author": "MOULIN", "origin": "C", "created": "20240210", "package": "ZPIBASE"}]}, "schema_version": "1", "support_packages": [{"time": "020000", "type": "Support Package", "patch": "SAPKB75026", "applied": "20250601", "component": "SAP_BASIS"}, {"time": "030000", "type": "Support Package", "patch": "SAPKIPYI7026", "applied": "20250601", "component": "PI_BASIS"}, {"time": "031500", "type": "Support Package", "patch": "SAPK-75026INXIESR", "applied": "20250601", "component": "XIESR"}]}
e4577de3-5f63-49b2-a7bf-e2ae9b0a7fc3	96011f52-5adc-4bec-a663-319d125760ee	PO1	sap-po1-prd.acme.local	1	2026-03-28 22:31:31.843555+00	2026-03-28 22:32:31.843555+00	{"health": {"tablespaces": [{"name": "PSAPSR3", "used_pct": 91.3}, {"name": "PSAPUNDO", "used_pct": 55.2}, {"name": "PSAPSR3USR", "used_pct": 78.4}, {"name": "PSAPTEMP", "used_pct": 42.0}]}, "system": {"rfchost": "sap-po1-prd.acme.local", "rfcmach": "x86_64", "rfcdayst": "X", "rfcdbsys": "ORA", "rfcopsys": "Linux", "rfcsaprl": "750", "rfcsysid": "PO1", "rfctzone": "3600", "rfcdbhost": "hana-po1.acme.local", "rfcipaddr": "10.0.1.70", "rfckernrl": "777", "rfcipv6addr": ""}, "db_stats": {"db_type": "ORA", "db_version": "19.0.0.0.0"}, "instances": [{"wp": {"bgd": 4, "dia": 8, "enq": 1, "spo": 1, "upd": 2, "busy": 2, "free": 6}, "host": "po1app01", "name": "PO1_DVEBMGS00", "type": "ABAP", "release": "756"}], "components": [{"release": "750", "component": "SAP_BASIS", "extrelease": "0025", "description": "SAP Basis Component"}, {"release": "750", "component": "SAP_ABA", "extrelease": "0025", "description": "Cross-Application Component"}, {"release": "750", "component": "PI_BASIS", "extrelease": "0025", "description": "SAP Process Orchestration Basis"}, {"release": "750", "component": "XIESR", "extrelease": "0025", "description": "Enterprise Services Repository"}, {"release": "750", "component": "XIAF", "extrelease": "0025", "description": "Advanced Adapter Framework"}, {"release": "750", "component": "XIRWB", "extrelease": "0025", "description": "Integration Workbench"}, {"release": "750", "component": "BPEM", "extrelease": "0025", "description": "Business Process Exception Mgmt"}], "performance": {"avg_response_ms": 820, "buffer_hit_rates": {"CUA": 98.7, "TABLE": 87.1, "NAMETAB": 99.1, "PROGRAM": 94.2}, "dialog_steps_today": 12400}, "system_type": "PI/PO", "collected_at": "2026-03-28T08:09:00+00:00", "custom_objects": {"total": 476, "by_type": {"CLAS": 76, "DOMA": 26, "DTEL": 34, "INTF": 58, "PROG": 87, "SWFL": 143, "TABL": 52}, "objects": [{"lang": "FR", "name": "ZACME_INTERCO_IDOC", "type": "SWFL", "author": "MARTINB", "origin": "C", "created": "20190915", "package": "ZPOACME"}, {"lang": "FR", "name": "ZCL_PO_VENDOR_MAPPER", "type": "CLAS", "author": "MARTINB", "origin": "C", "created": "20210530", "package": "ZPOACME"}, {"lang": "FR", "name": "ZACME_PO_ERROR_REPORT", "type": "PROG", "author": "BLANCP", "origin": "C", "created": "20230801", "package": "ZPOACME"}]}, "profile_params": {"em/max_size_MB": "3000", "rdisp/wp_no_vb": "2", "rdisp/tm_max_no": "500", "rdisp/wp_no_btc": "4", "rdisp/wp_no_dia": "8", "rdisp/wp_no_spo": "1", "rdisp/ROLL_MAXFS": "16384", "em/initial_size_MB": "1500", "abap/heap_area_total": "2000000000", "rdisp/max_wprun_time": "600"}, "schema_version": "1", "support_packages": [{"time": "020000", "type": "Support Package", "patch": "SAPKB75025", "applied": "20241001", "component": "SAP_BASIS"}, {"time": "030000", "type": "Support Package", "patch": "SAPKIPYI7025", "applied": "20241001", "component": "PI_BASIS"}, {"time": "031500", "type": "Support Package", "patch": "SAPK-75025INXIESR", "applied": "20241001", "component": "XIESR"}]}
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: sapscope
--

COPY public.subscriptions (id, user_id, stripe_customer_id, stripe_subscription_id, tier, status, created_at, updated_at) FROM stdin;
9aa251ec-746f-4dc0-bcc2-a3ace4ca1f68	dcba369f-0355-4e96-87d9-2e539e954ef3	cus_UG34RxD5vbIdhe	sub_1THWyJ1mgLHVFj5OOmnx7vYo	solo	active	2026-04-01 22:10:49.988321+00	2026-04-01 22:10:49.988321+00
\.


--
-- Data for Name: system_notes; Type: TABLE DATA; Schema: public; Owner: sapscope
--

COPY public.system_notes (id, client_id, system_sid, content, author_email, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_clients; Type: TABLE DATA; Schema: public; Owner: sapscope
--

COPY public.user_clients (user_id, client_id) FROM stdin;
6c900746-1991-4dc2-a475-da36c4221923	f3e267a0-86cb-4ac5-adeb-af80b35595fb
6c900746-1991-4dc2-a475-da36c4221923	96011f52-5adc-4bec-a663-319d125760ee
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: sapscope
--

COPY public.users (id, email, password_hash, is_admin, created_at) FROM stdin;
cec7be8c-e79c-4c70-8dd0-d176c439ec15	pro@luku.fr	$2b$12$utJIhr2buwWqRrDdatFDlOU9mF5w9kE6KctHjNQ83pZYMGc/FekVm	t	2026-03-28 14:17:56.650663+00
fb315b38-a32c-4804-a0d8-f93d366820df	consultant@sap.fr	$2b$12$LyaFivBFolQ.sJMhJKbWZeB3n9v/n3teOI9aR9464KEPs49PQr9cW	f	2026-03-31 22:01:13.920621+00
6c900746-1991-4dc2-a475-da36c4221923	demo@sapscope.fr	$2b$12$rEeyCXVv81S3CUt0eQYByObo60ppf/ABQ5ikUbomJhRrWSslCTwRC	f	2026-04-01 08:32:23.931261+00
dcba369f-0355-4e96-87d9-2e539e954ef3	llautrec@oxya.com	$2b$12$BIqdEyMNMLhis9SsDn6lZuJHruyYtasnUe/uEVWokHkix8R4DouYS	f	2026-04-01 22:10:01.795279+00
\.


--
-- Name: agent_tokens agent_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.agent_tokens
    ADD CONSTRAINT agent_tokens_pkey PRIMARY KEY (id);


--
-- Name: agent_tokens agent_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.agent_tokens
    ADD CONSTRAINT agent_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: analyses analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_pkey PRIMARY KEY (id);


--
-- Name: analyses analyses_snapshot_id_key; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_snapshot_id_key UNIQUE (snapshot_id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: health_checks health_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.health_checks
    ADD CONSTRAINT health_checks_pkey PRIMARY KEY (id);


--
-- Name: health_checks health_checks_snapshot_id_key; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.health_checks
    ADD CONSTRAINT health_checks_snapshot_id_key UNIQUE (snapshot_id);


--
-- Name: licenses licenses_pkey; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.licenses
    ADD CONSTRAINT licenses_pkey PRIMARY KEY (id);


--
-- Name: onboarding_tokens onboarding_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.onboarding_tokens
    ADD CONSTRAINT onboarding_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: snapshots snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.snapshots
    ADD CONSTRAINT snapshots_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_user_id_key; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_key UNIQUE (user_id);


--
-- Name: system_notes system_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.system_notes
    ADD CONSTRAINT system_notes_pkey PRIMARY KEY (id);


--
-- Name: user_clients user_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.user_clients
    ADD CONSTRAINT user_clients_pkey PRIMARY KEY (user_id, client_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_health_checks_snapshot; Type: INDEX; Schema: public; Owner: sapscope
--

CREATE INDEX ix_health_checks_snapshot ON public.health_checks USING btree (snapshot_id);


--
-- Name: ix_licenses_key; Type: INDEX; Schema: public; Owner: sapscope
--

CREATE UNIQUE INDEX ix_licenses_key ON public.licenses USING btree (key);


--
-- Name: ix_prt_user; Type: INDEX; Schema: public; Owner: sapscope
--

CREATE INDEX ix_prt_user ON public.password_reset_tokens USING btree (user_id);


--
-- Name: ix_snapshots_client_collected; Type: INDEX; Schema: public; Owner: sapscope
--

CREATE INDEX ix_snapshots_client_collected ON public.snapshots USING btree (client_id, collected_at DESC);


--
-- Name: ix_snapshots_payload_gin; Type: INDEX; Schema: public; Owner: sapscope
--

CREATE INDEX ix_snapshots_payload_gin ON public.snapshots USING gin (payload);


--
-- Name: ix_snapshots_sid; Type: INDEX; Schema: public; Owner: sapscope
--

CREATE INDEX ix_snapshots_sid ON public.snapshots USING btree (system_sid);


--
-- Name: ix_system_notes_client_sid; Type: INDEX; Schema: public; Owner: sapscope
--

CREATE INDEX ix_system_notes_client_sid ON public.system_notes USING btree (client_id, system_sid);


--
-- Name: agent_tokens agent_tokens_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.agent_tokens
    ADD CONSTRAINT agent_tokens_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: analyses analyses_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_snapshot_id_fkey FOREIGN KEY (snapshot_id) REFERENCES public.snapshots(id) ON DELETE CASCADE;


--
-- Name: health_checks health_checks_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.health_checks
    ADD CONSTRAINT health_checks_snapshot_id_fkey FOREIGN KEY (snapshot_id) REFERENCES public.snapshots(id) ON DELETE CASCADE;


--
-- Name: onboarding_tokens onboarding_tokens_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.onboarding_tokens
    ADD CONSTRAINT onboarding_tokens_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: onboarding_tokens onboarding_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.onboarding_tokens
    ADD CONSTRAINT onboarding_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: snapshots snapshots_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.snapshots
    ADD CONSTRAINT snapshots_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: system_notes system_notes_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.system_notes
    ADD CONSTRAINT system_notes_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: user_clients user_clients_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.user_clients
    ADD CONSTRAINT user_clients_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: user_clients user_clients_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sapscope
--

ALTER TABLE ONLY public.user_clients
    ADD CONSTRAINT user_clients_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 1a44CUcYCeOAkmbgbmqGj60webjRdVg8ozfChaGkVt9ZKG6VdjXTGY8NjOPXz0V

